import React from 'react'
// import Navbar from './Navbar/page'
import HomePage from './HomePage/page'


const page = () => {
  return (
    <div>
      {/* <Navbar/> */}
      <HomePage/>
     
    </div>
  )
}

export default page